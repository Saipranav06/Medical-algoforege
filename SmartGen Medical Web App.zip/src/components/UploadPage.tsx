import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Upload, FileText, CheckCircle } from "lucide-react";

interface UploadPageProps {
  setCurrentPage: (page: string) => void;
}

export function UploadPage({ setCurrentPage }: UploadPageProps) {
  const [dragActive, setDragActive] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setUploadedFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setUploadedFile(e.target.files[0]);
    }
  };

  const handleSubmit = () => {
    if (uploadedFile) {
      setIsProcessing(true);
      // Simulate processing time
      setTimeout(() => {
        setIsProcessing(false);
        setCurrentPage('results');
      }, 3000);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-secondary via-white to-muted py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl text-foreground mb-4">Upload DNA Sequence</h1>
          <p className="text-lg text-muted-foreground">
            Upload bacterial DNA sequence to detect resistance genes and mutations
          </p>
        </div>

        <div className="grid gap-8">
          {/* Upload Section */}
          <Card className="bg-white shadow-xl rounded-2xl border-0">
            <CardHeader>
              <CardTitle className="text-2xl text-center text-foreground">
                Upload Your Sequence File
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              <div
                className={`relative border-2 border-dashed rounded-xl p-12 text-center transition-colors ${
                  dragActive 
                    ? 'border-primary bg-primary/5' 
                    : uploadedFile
                    ? 'border-green-500 bg-green-50'
                    : 'border-border bg-muted/20 hover:border-primary hover:bg-primary/5'
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <input
                  type="file"
                  accept=".fasta,.fa,.fastq,.fq,.txt"
                  onChange={handleFileSelect}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                
                <div className="space-y-4">
                  {uploadedFile ? (
                    <>
                      <CheckCircle className="h-16 w-16 text-green-500 mx-auto" />
                      <div>
                        <h3 className="text-xl text-foreground mb-2">File Selected</h3>
                        <p className="text-muted-foreground">{uploadedFile.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {(uploadedFile.size / (1024 * 1024)).toFixed(2)} MB
                        </p>
                      </div>
                    </>
                  ) : (
                    <>
                      <Upload className="h-16 w-16 text-muted-foreground mx-auto" />
                      <div>
                        <h3 className="text-xl text-foreground mb-2">
                          Drag and drop your file here
                        </h3>
                        <p className="text-muted-foreground mb-4">
                          or click to browse files
                        </p>
                        <p className="text-sm text-muted-foreground">
                          Supported formats: FASTA, FASTQ, TXT (Max 100MB)
                        </p>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {uploadedFile && (
                <div className="mt-8 text-center">
                  <Button 
                    size="lg" 
                    onClick={handleSubmit}
                    disabled={isProcessing}
                    className="px-8 py-3 rounded-xl bg-primary hover:bg-primary/90"
                  >
                    {isProcessing ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                        Processing...
                      </>
                    ) : (
                      'Analyze Sequence'
                    )}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Instructions */}
          <Card className="bg-white shadow-lg rounded-2xl border-0">
            <CardHeader>
              <CardTitle className="text-xl text-foreground flex items-center gap-2">
                <FileText className="h-6 w-6" />
                File Requirements
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-primary mb-2">Accepted Formats</h4>
                  <ul className="space-y-1 text-muted-foreground">
                    <li>• FASTA (.fasta, .fa)</li>
                    <li>• FASTQ (.fastq, .fq)</li>
                    <li>• Plain text (.txt)</li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-primary mb-2">Quality Guidelines</h4>
                  <ul className="space-y-1 text-muted-foreground">
                    <li>• High-quality sequencing data</li>
                    <li>• Complete or near-complete genomes</li>
                    <li>• Minimum 1000 base pairs</li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-muted/50 rounded-lg p-4 border-l-4 border-primary">
                <h4 className="text-primary mb-2">Processing Time</h4>
                <p className="text-muted-foreground">
                  Analysis typically takes 2-5 minutes depending on sequence length and complexity. 
                  You'll be automatically redirected to results when processing is complete.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}