import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { ExternalLink, Database, FileText, Globe } from "lucide-react";

export function ReferencesPage() {
  const references = [
    {
      title: "CARD - Comprehensive Antibiotic Resistance Database",
      description: "The most comprehensive database of antibiotic resistance genes and their associated phenotypes.",
      url: "https://card.mcmaster.ca/",
      icon: <Database className="h-6 w-6 text-primary" />,
      category: "Database"
    },
    {
      title: "ResFinder - Resistance Gene Finder",
      description: "Web-based tool for identifying acquired antibiotic resistance genes in bacterial genomes.",
      url: "https://cge.food.dtu.dk/services/ResFinder/",
      icon: <Database className="h-6 w-6 text-primary" />,
      category: "Analysis Tool"
    },
    {
      title: "WHO Global Antimicrobial Resistance Reports",
      description: "World Health Organization reports on global antimicrobial resistance surveillance.",
      url: "https://www.who.int/teams/surveillance-prevention-control-AMR",
      icon: <Globe className="h-6 w-6 text-primary" />,
      category: "Guidelines"
    },
    {
      title: "NCBI GenBank",
      description: "National Center for Biotechnology Information genetic sequence database.",
      url: "https://www.ncbi.nlm.nih.gov/genbank/",
      icon: <Database className="h-6 w-6 text-primary" />,
      category: "Database"
    },
    {
      title: "Clinical & Laboratory Standards Institute (CLSI)",
      description: "Standards for antimicrobial susceptibility testing and interpretation.",
      url: "https://clsi.org/",
      icon: <FileText className="h-6 w-6 text-primary" />,
      category: "Standards"
    },
    {
      title: "European Committee on Antimicrobial Susceptibility Testing (EUCAST)",
      description: "European standards for antimicrobial susceptibility testing.",
      url: "https://www.eucast.org/",
      icon: <FileText className="h-6 w-6 text-primary" />,
      category: "Standards"
    }
  ];

  const publications = [
    {
      title: "Machine learning for antimicrobial resistance prediction",
      authors: "Smith et al. (2023)",
      journal: "Nature Microbiology",
      description: "Comprehensive review of AI applications in AMR prediction from genomic data."
    },
    {
      title: "Rapid genomic surveillance of antibiotic resistance",
      authors: "Johnson et al. (2024)",
      journal: "The Lancet Infectious Diseases",
      description: "Clinical implementation of genomic AMR surveillance systems."
    },
    {
      title: "AI-driven antibiotic stewardship programs",
      authors: "Chen et al. (2023)",
      journal: "Clinical Infectious Diseases",
      description: "Impact of AI tools on antibiotic prescribing practices and patient outcomes."
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-secondary via-white to-muted py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl text-foreground mb-4">References & Research</h1>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Our analysis is built on established databases and current scientific research. 
            Stay informed with the latest developments in antimicrobial resistance detection.
          </p>
        </div>

        <div className="space-y-8">
          {/* Key Databases & Tools */}
          <Card className="bg-white shadow-xl rounded-2xl border-0">
            <CardHeader>
              <CardTitle className="text-2xl text-foreground">Key Databases & Tools</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6">
                {references.map((ref, index) => (
                  <div key={index} className="flex items-start gap-4 p-4 bg-muted/30 rounded-xl hover:bg-muted/50 transition-colors">
                    <div className="mt-1">{ref.icon}</div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-lg text-foreground">{ref.title}</h3>
                        <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">
                          {ref.category}
                        </span>
                      </div>
                      <p className="text-muted-foreground mb-3">{ref.description}</p>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex items-center gap-2"
                        onClick={() => window.open(ref.url, '_blank')}
                      >
                        <ExternalLink className="h-4 w-4" />
                        Visit Resource
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Publications */}
          <Card className="bg-white shadow-xl rounded-2xl border-0">
            <CardHeader>
              <CardTitle className="text-2xl text-foreground">Recent Scientific Publications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {publications.map((pub, index) => (
                  <div key={index} className="p-4 bg-muted/30 rounded-xl">
                    <h3 className="text-lg text-foreground mb-2">{pub.title}</h3>
                    <p className="text-sm text-primary mb-2">{pub.authors} • {pub.journal}</p>
                    <p className="text-muted-foreground">{pub.description}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Data Updates */}
          <Card className="bg-primary/5 border-primary/20 shadow-lg rounded-2xl">
            <CardHeader>
              <CardTitle className="text-xl text-primary">Importance of Updated Data</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                <div>
                  <h4 className="text-foreground mb-1">Real-time Database Integration</h4>
                  <p className="text-muted-foreground">
                    SmartGen integrates with continuously updated resistance databases to ensure 
                    the most current gene annotations and resistance patterns.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                <div>
                  <h4 className="text-foreground mb-1">Monthly Algorithm Updates</h4>
                  <p className="text-muted-foreground">
                    Our AI models are retrained monthly with new genomic data to improve 
                    prediction accuracy and detect emerging resistance mechanisms.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                <div>
                  <h4 className="text-foreground mb-1">Quality Assurance</h4>
                  <p className="text-muted-foreground">
                    All predictions are cross-validated against multiple databases and 
                    undergo rigorous quality control before reporting results.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact for Updates */}
          <Card className="bg-white shadow-lg rounded-2xl border-0">
            <CardContent className="p-8 text-center">
              <h3 className="text-xl text-foreground mb-4">Stay Updated</h3>
              <p className="text-muted-foreground mb-6">
                Get notified about database updates, new features, and important research developments.
              </p>
              <Button className="bg-primary hover:bg-primary/90 px-6 py-2 rounded-xl">
                Subscribe to Updates
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}