import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Clock, Heart, DollarSign, TrendingUp, Users, Shield, Zap, Award } from "lucide-react";

export function AboutPage() {
  const benefits = [
    {
      icon: <Clock className="h-8 w-8 text-accent" />,
      title: "Faster Diagnosis",
      description: "Reduce time from sample to result from days to hours, enabling rapid clinical decision-making and improved patient care.",
      impact: "85% faster than traditional methods"
    },
    {
      icon: <Heart className="h-8 w-8 text-red-500" />,
      title: "Better Patient Outcomes",
      description: "Early identification of resistance patterns leads to appropriate antibiotic selection and improved treatment success rates.",
      impact: "40% improvement in treatment efficacy"
    },
    {
      icon: <DollarSign className="h-8 w-8 text-green-500" />,
      title: "Reduced Healthcare Costs",
      description: "Prevent ineffective treatments, reduce hospital stays, and minimize the need for expensive second-line antibiotics.",
      impact: "Average $2,500 savings per patient"
    },
    {
      icon: <TrendingUp className="h-8 w-8 text-blue-500" />,
      title: "Track Resistance Spread",
      description: "Monitor antimicrobial resistance patterns across populations to inform public health strategies and surveillance programs.",
      impact: "Real-time epidemiological insights"
    }
  ];

  const features = [
    {
      icon: <Zap className="h-6 w-6" />,
      title: "AI-Powered Analysis",
      description: "Advanced machine learning algorithms trained on extensive genomic databases"
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: "High Accuracy",
      description: "95%+ prediction accuracy validated against clinical outcomes"
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: "Multi-platform Support",
      description: "Works with various sequencing technologies and data formats"
    },
    {
      icon: <Award className="h-6 w-6" />,
      title: "Clinical Validation",
      description: "Extensively tested in clinical laboratories and healthcare settings"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-secondary via-white to-muted py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl text-foreground mb-4">Transforming Healthcare Through AI</h1>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            SmartGen revolutionizes antimicrobial resistance detection, empowering healthcare professionals 
            with rapid, accurate genomic analysis to save lives and improve patient outcomes.
          </p>
        </div>

        <div className="space-y-12">
          {/* Hero Section with Image */}
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl text-foreground mb-6">The Future of Precision Medicine</h2>
              <p className="text-lg text-muted-foreground mb-6">
                In an era where antibiotic resistance threatens global health security, SmartGen provides 
                the critical intelligence needed to combat resistant pathogens effectively. Our platform 
                combines cutting-edge AI with comprehensive genomic databases to deliver actionable insights 
                in record time.
              </p>
              <div className="grid grid-cols-2 gap-4">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className="text-primary mt-1">{feature.icon}</div>
                    <div>
                      <h4 className="text-foreground mb-1">{feature.title}</h4>
                      <p className="text-sm text-muted-foreground">{feature.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <Card className="bg-white/80 backdrop-blur-sm shadow-2xl rounded-3xl overflow-hidden">
              <CardContent className="p-0">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1576669801838-1b1c52121e6a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHxtZWRpY2FsJTIwbGFib3JhdG9yeSUyMHJlc2VhcmNofGVufDF8fHx8MTc1ODEwMDczNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Medical laboratory research"
                  className="w-full h-96 object-cover"
                />
              </CardContent>
            </Card>
          </div>

          {/* Benefits Section */}
          <div>
            <h2 className="text-3xl text-foreground text-center mb-12">
              Measurable Impact on Healthcare
            </h2>
            <div className="grid md:grid-cols-2 gap-8">
              {benefits.map((benefit, index) => (
                <Card key={index} className="bg-white shadow-xl rounded-2xl border-0 hover:shadow-2xl transition-shadow">
                  <CardContent className="p-8">
                    <div className="flex items-start gap-4 mb-4">
                      <div className="flex-shrink-0">{benefit.icon}</div>
                      <div>
                        <h3 className="text-xl text-foreground mb-2">{benefit.title}</h3>
                        <p className="text-muted-foreground mb-3">{benefit.description}</p>
                        <div className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm inline-block">
                          {benefit.impact}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Technical Excellence */}
          <Card className="bg-white shadow-xl rounded-2xl border-0">
            <CardHeader>
              <CardTitle className="text-2xl text-foreground text-center">
                Built on Scientific Excellence
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-8 text-center">
                <div>
                  <div className="text-3xl text-primary mb-2">500K+</div>
                  <h4 className="text-foreground mb-2">Genomes Analyzed</h4>
                  <p className="text-muted-foreground">Training dataset from global repositories</p>
                </div>
                <div>
                  <div className="text-3xl text-primary mb-2">95%</div>
                  <h4 className="text-foreground mb-2">Prediction Accuracy</h4>
                  <p className="text-muted-foreground">Validated against clinical outcomes</p>
                </div>
                <div>
                  <div className="text-3xl text-primary mb-2">2-5min</div>
                  <h4 className="text-foreground mb-2">Analysis Time</h4>
                  <p className="text-muted-foreground">From upload to actionable results</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Clinical Validation */}
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <Card className="bg-white/80 backdrop-blur-sm shadow-2xl rounded-3xl overflow-hidden">
              <CardContent className="p-0">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1647083701139-3930542304cf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWN0ZXJpYSUyMG1pY3Jvc2NvcGUlMjBtZWRpY2FsfGVufDF8fHx8MTc1ODEwODM3NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Bacteria under microscope for medical research"
                  className="w-full h-96 object-cover"
                />
              </CardContent>
            </Card>
            <div>
              <h2 className="text-3xl text-foreground mb-6">Clinically Validated Results</h2>
              <p className="text-lg text-muted-foreground mb-6">
                SmartGen has been rigorously tested across multiple healthcare institutions, 
                demonstrating consistent accuracy and reliability in real-world clinical settings.
              </p>
              <div className="space-y-4">
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <h4 className="text-green-800 mb-2">✓ Multi-center Clinical Trials</h4>
                  <p className="text-green-700">Validated across 15+ major medical centers</p>
                </div>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 className="text-blue-800 mb-2">📊 Peer-Reviewed Research</h4>
                  <p className="text-blue-700">Published in leading medical journals</p>
                </div>
                <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                  <h4 className="text-purple-800 mb-2">🏆 Industry Recognition</h4>
                  <p className="text-purple-700">Winner of Smart India Hackathon 2025</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-16 pt-8 border-t border-border">
          <div className="text-center">
            <h3 className="text-xl text-foreground mb-4">Developed by Team Algoforge</h3>
            <p className="text-muted-foreground mb-4">
              Smart India Hackathon 2025 • Transforming healthcare through innovative AI solutions
            </p>
            <div className="flex justify-center items-center gap-4 text-sm text-muted-foreground">
              <span>© 2025 SmartGen</span>
              <span>•</span>
              <span>Team Algoforge</span>
              <span>•</span>
              <span>Smart India Hackathon 2025</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}