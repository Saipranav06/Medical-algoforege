import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Dna, Clock, Shield, TrendingUp } from "lucide-react";

interface LandingPageProps {
  setCurrentPage: (page: string) => void;
}

export function LandingPage({ setCurrentPage }: LandingPageProps) {
  const features = [
    {
      icon: <Clock className="h-8 w-8 text-accent" />,
      title: "Rapid Analysis",
      description: "Get results in hours instead of days"
    },
    {
      icon: <Dna className="h-8 w-8 text-accent" />,
      title: "AI-Powered",
      description: "Advanced genomic analysis algorithms"
    },
    {
      icon: <Shield className="h-8 w-8 text-accent" />,
      title: "Accurate Predictions",
      description: "High precision resistance detection"
    },
    {
      icon: <TrendingUp className="h-8 w-8 text-accent" />,
      title: "Better Outcomes",
      description: "Improve patient treatment success"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-secondary via-white to-muted">
      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl text-foreground leading-tight">
                SmartGen: AI for Rapid 
                <span className="text-primary block">Antibiotic Resistance Detection</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-lg">
                Upload bacterial DNA sequences and get rapid resistance predictions within hours instead of days. 
                Revolutionizing treatment decisions with AI-powered genomic analysis.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg" 
                onClick={() => setCurrentPage('upload')}
                className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-3 rounded-xl"
              >
                Get Started
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => setCurrentPage('about')}
                className="px-8 py-3 rounded-xl border-primary text-primary hover:bg-primary/5"
              >
                Learn More
              </Button>
            </div>
          </div>
          
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-primary to-accent rounded-3xl opacity-10 blur-3xl"></div>
            <Card className="relative bg-white/80 backdrop-blur-sm shadow-2xl rounded-3xl overflow-hidden">
              <CardContent className="p-0">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1579154204628-0489d1e5c0f2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxETkElMjBnZW5vbWljcyUyMG1lZGljYWwlMjBoZWFsdGhjYXJlfGVufDF8fHx8MTc1ODEwODM3M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="DNA genomics and healthcare technology"
                  className="w-full h-96 object-cover"
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h2 className="text-3xl text-foreground mb-4">
            Transforming Healthcare with AI Genomics
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Our advanced platform combines cutting-edge AI with genomic analysis to provide 
            healthcare professionals with rapid, accurate antibiotic resistance predictions.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="bg-white shadow-lg rounded-2xl border-0 hover:shadow-xl transition-shadow">
              <CardContent className="p-8 text-center space-y-4">
                <div className="flex justify-center">{feature.icon}</div>
                <h3 className="text-xl text-foreground">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-primary text-primary-foreground py-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl mb-4">Ready to Transform Your Laboratory?</h2>
          <p className="text-xl opacity-90 mb-8">
            Join leading healthcare institutions using SmartGen for faster, more accurate resistance testing.
          </p>
          <Button 
            size="lg" 
            variant="secondary"
            onClick={() => setCurrentPage('upload')}
            className="px-8 py-3 rounded-xl"
          >
            Start Your Analysis
          </Button>
        </div>
      </div>
    </div>
  );
}