import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { CheckCircle, XCircle, AlertTriangle, Download, Share2 } from "lucide-react";

interface ResultsPageProps {
  setCurrentPage: (page: string) => void;
}

export function ResultsPage({ setCurrentPage }: ResultsPageProps) {
  const resistanceGenes = [
    { gene: "blaTEM-1", type: "Beta-lactamase", status: "detected", confidence: 98 },
    { gene: "aac(6')-Ib", type: "Aminoglycoside", status: "detected", confidence: 95 },
    { gene: "qnrS1", type: "Quinolone", status: "detected", confidence: 92 },
    { gene: "sul1", type: "Sulfonamide", status: "detected", confidence: 89 },
    { gene: "tet(A)", type: "Tetracycline", status: "not_detected", confidence: null }
  ];

  const antibioticProfile = [
    { antibiotic: "Ampicillin", status: "resistant", alternative: "Carbapenems" },
    { antibiotic: "Gentamicin", status: "resistant", alternative: "Amikacin" },
    { antibiotic: "Ciprofloxacin", status: "resistant", alternative: "Tigecycline" },
    { antibiotic: "Trimethoprim-Sulfamethoxazole", status: "resistant", alternative: "Nitrofurantoin" },
    { antibiotic: "Tetracycline", status: "effective", alternative: null },
    { antibiotic: "Imipenem", status: "effective", alternative: null },
    { antibiotic: "Amikacin", status: "effective", alternative: null },
    { antibiotic: "Tigecycline", status: "effective", alternative: null }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "effective":
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case "resistant":
        return <XCircle className="h-5 w-5 text-red-600" />;
      case "detected":
        return <AlertTriangle className="h-5 w-5 text-orange-600" />;
      default:
        return <CheckCircle className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "effective":
        return <Badge className="bg-green-100 text-green-800">Effective</Badge>;
      case "resistant":
        return <Badge className="bg-red-100 text-red-800">Resistant</Badge>;
      case "detected":
        return <Badge className="bg-orange-100 text-orange-800">Detected</Badge>;
      case "not_detected":
        return <Badge className="bg-gray-100 text-gray-800">Not Detected</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-secondary via-white to-muted py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl text-foreground mb-4">Antibiotic Resistance Profile</h1>
          <p className="text-lg text-muted-foreground">
            Analysis completed • Sequence ID: SEQ_2025_001
          </p>
          <div className="flex justify-center gap-4 mt-6">
            <Button variant="outline" className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Download Report
            </Button>
            <Button variant="outline" className="flex items-center gap-2">
              <Share2 className="h-4 w-4" />
              Share Results
            </Button>
          </div>
        </div>

        <div className="grid gap-8">
          {/* Summary Cards */}
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="bg-red-50 border-red-200 shadow-lg rounded-2xl">
              <CardContent className="p-6 text-center">
                <div className="text-3xl text-red-600 mb-2">4</div>
                <p className="text-red-800">Resistance Genes Detected</p>
              </CardContent>
            </Card>
            <Card className="bg-green-50 border-green-200 shadow-lg rounded-2xl">
              <CardContent className="p-6 text-center">
                <div className="text-3xl text-green-600 mb-2">4</div>
                <p className="text-green-800">Effective Antibiotics</p>
              </CardContent>
            </Card>
            <Card className="bg-blue-50 border-blue-200 shadow-lg rounded-2xl">
              <CardContent className="p-6 text-center">
                <div className="text-3xl text-blue-600 mb-2">95%</div>
                <p className="text-blue-800">Average Confidence</p>
              </CardContent>
            </Card>
          </div>

          {/* Resistance Genes */}
          <Card className="bg-white shadow-xl rounded-2xl border-0">
            <CardHeader>
              <CardTitle className="text-2xl text-foreground">Detected Resistance Genes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {resistanceGenes.map((gene, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-muted/30 rounded-xl">
                    <div className="flex items-center gap-4">
                      {getStatusIcon(gene.status)}
                      <div>
                        <h4 className="text-foreground">{gene.gene}</h4>
                        <p className="text-sm text-muted-foreground">{gene.type} resistance</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      {gene.confidence && (
                        <span className="text-sm text-muted-foreground">
                          {gene.confidence}% confidence
                        </span>
                      )}
                      {getStatusBadge(gene.status)}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Antibiotic Profile */}
          <Card className="bg-white shadow-xl rounded-2xl border-0">
            <CardHeader>
              <CardTitle className="text-2xl text-foreground">Recommended Treatment Options</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {antibioticProfile.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-muted/30 rounded-xl">
                    <div className="flex items-center gap-4">
                      {getStatusIcon(item.status)}
                      <div>
                        <h4 className="text-foreground">{item.antibiotic}</h4>
                        {item.alternative && (
                          <p className="text-sm text-muted-foreground">
                            Alternative: {item.alternative}
                          </p>
                        )}
                      </div>
                    </div>
                    {getStatusBadge(item.status)}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Clinical Recommendations */}
          <Card className="bg-primary/5 border-primary/20 shadow-lg rounded-2xl">
            <CardHeader>
              <CardTitle className="text-xl text-primary">Clinical Recommendations</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <h4 className="text-green-800 mb-2">✓ Recommended First-Line Treatments</h4>
                <p className="text-green-700">Imipenem, Amikacin, Tigecycline, or Tetracycline</p>
              </div>
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <h4 className="text-red-800 mb-2">⚠ Avoid These Antibiotics</h4>
                <p className="text-red-700">Ampicillin, Gentamicin, Ciprofloxacin, Trimethoprim-Sulfamethoxazole</p>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="text-blue-800 mb-2">📋 Additional Notes</h4>
                <p className="text-blue-700">
                  Consider antimicrobial stewardship protocols. Monitor for treatment response and adjust based on clinical outcomes.
                  Results should be interpreted in conjunction with clinical presentation and patient history.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="text-center">
            <Button 
              onClick={() => setCurrentPage('upload')}
              className="bg-primary hover:bg-primary/90 px-8 py-3 rounded-xl"
            >
              Analyze Another Sequence
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}