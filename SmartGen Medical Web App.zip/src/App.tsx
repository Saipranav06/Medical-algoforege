import { useState } from "react";
import { Navigation } from "./components/Navigation";
import { LandingPage } from "./components/LandingPage";
import { UploadPage } from "./components/UploadPage";
import { ResultsPage } from "./components/ResultsPage";
import { ReferencesPage } from "./components/ReferencesPage";
import { AboutPage } from "./components/AboutPage";

export default function App() {
  const [currentPage, setCurrentPage] = useState("home");

  const renderPage = () => {
    switch (currentPage) {
      case "home":
        return <LandingPage setCurrentPage={setCurrentPage} />;
      case "upload":
        return <UploadPage setCurrentPage={setCurrentPage} />;
      case "results":
        return <ResultsPage setCurrentPage={setCurrentPage} />;
      case "references":
        return <ReferencesPage />;
      case "about":
        return <AboutPage />;
      default:
        return <LandingPage setCurrentPage={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation currentPage={currentPage} setCurrentPage={setCurrentPage} />
      {renderPage()}
    </div>
  );
}